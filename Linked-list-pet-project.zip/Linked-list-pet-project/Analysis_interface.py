from dragon_info import Dragon_info
from dragon_dict import DragonInfoDict
from dragon_dictionary_sort import DragonInfoSort
from Hash_dragon_dictionary import Dragon_Dictionary_Hash
import time # importing the time to calcuate the time needed to run the queries
import random # generating random numbers

#TODO: fix the interface to reduce repition
#TODO: add options to ask which implementation to run

class Analysis_Interface: # Holds the functions for the interface
  @staticmethod
  def print_intro():
      print("                   * * * * * * *")
      print("                *                *")
      print("               *  * * * * * * * *     *")
      print("         * *  *  * * * *        * * * *")
      print("       *                *")
      print("     *  0                  *")
      print("  *                         *")
      print("*Welcome to our Dragon Retrieval System")
      print("*         *                     *")
      print(" * * * * *                           *")
      print("    *                *  * *")
      print("      *            *         *")
      print("        *  *  *  *            *")
      print("                                 *")
      #Susie
      print("Before putting in options, you must enter a file [1]")
      print("[0] - Exit program/Save changes!")
      print("[1] - Input file")
      print("[2] - Input query")
      print("[3] - Add dragon info")
      print("[4] - Delete dragon info")
      print("[5] - Print dragon info list")
      print("[6] - Search by Powerlevel.")
      print("[7] - Print a reminder for all existing options!")

  @staticmethod
  # a command line interface for dragon info retrieval system
  def dragon_retrievalcl():
      Analysis_Interface.print_intro()

      dInfo = Dragon_info()
      #Susie
      option = 1
      while (option != 0):
          #exception handling
          try:
              option = int(input("Option: "))
          except ValueError:
              print(
                  "Wrong value, please try again, only input numbers 1 to 7")
              option = int(input("Option: "))
          #Susie
          # enter the path to the files to build the system
          if option == 1:
              file_name = input("Enter the name of data file: ")
              dInfo.create_dragon_info(file_name)
          #Susie
          elif option == 2:
              species = str.lower(input("Enter the dragon species: "))
              dragon = dInfo.search_dragon(species)
              if dragon == None:
                  print("Dragon not found")
              else:
                  print(dragon)

          #Peyton
          elif option == 3:
              print(
                  "Enter a dragon species, power level, ability, and location!"
              )
              name_of_species = str.lower(input("Add a dragon: "))
              dInfo.add_to_list(name_of_species)

#Blake Love
          elif option == 4:
              Announcement = str.upper(
                  input("*WARNING YOU WILL BE DELETING A DRAGON*" + "\n" +
                        "Are you sure Y/N: "))
              #gives the user a warning that they are about to delete info, and promts the user to say yes or no before they do
              if Announcement == "Y":
                  name_of_species = str.lower(
                      input(
                          "Which species information would you like to delete? "
                      ))
                  dInfo.delete_from_list(name_of_species)
#calls the delte_from_list function
              elif Announcement == "N":
                  option
#Blake Love
          elif option == 5:
              print("This is the full list!")
              dInfo.print_function()
          #Susie - backup function, call __str__ for printing
          #   print(dInfo)
#shows the whole list
#Peyton
          elif option == 6:
              power_info = input(
                  "Enter the power level that you are looking for: ")
              power = " "
              level = dInfo.dragon_power_level(power_info)
              for i in level:
                  power += i.line()
              if power == " ":
                  print("No match Dragon")
              print(power)

#Blake
          elif option == 7:
              dInfo.option_list()

#calls the option function to show full list of options
          elif option == 0:
              # dInfo.write_back()
              print("All changes were saved.")
#__________________________________________________________________
  @staticmethod
  def dragon_retrieval_dictionary():
    Analysis_Interface.print_intro()

    dInfo = DragonInfoDict()
    option = 1
    while (option != 0):
        try:
          option = int(input("Option: "))
        except ValueError:
          print(
                "Wrong value, please try again, only input numbers 1 to 7")
          option = int(input("Option: "))

        if option == 1:
          file_name = input("Enter the name of data file: ")
          dInfo.create_dragon_info(file_name)

        elif option == 2:
          species = str.lower(input("Enter the dragon species: "))
          dragon = dInfo.search_dragon(species)
          if dragon == None:
            print("Dragon not found")
          else:
            print(dragon)


        elif option == 3:
          print("Enter a dragon species, power level, ability, and location!")
          name_of_species = str.lower(input("Add a dragon: "))
          add_power_level = int(input("Add the power level: "))
          add_abilities = str.lower(input("Add the abilities: "))
          add_location = str.lower(input("Add the location: "))
          dInfo.add_to_list(name_of_species, add_power_level, add_abilities, add_location)


        elif option == 4:
          Announcement = str.upper(
            input("*WARNING YOU WILL BE DELETING A DRAGON*" + "\n" +
                    "Are you sure Y/N: "))

          if Announcement == "Y":
            name_of_species = str.lower(
                input(
                      "Which species information would you like to delete? "
                  ))
            dInfo.delete_from_dictionary(name_of_species)
#calls the delte_from_list function
          elif Announcement == "N":
            option
#Blake Love
        elif option == 5:
          print("This is the full list!")
          dInfo.print_dictionary()
        
#Peyton
        elif option == 6:
          power_info = input(
              "Enter the power level that you are looking for: ")
          power = " "
          level = dInfo.dragon_power_level(power_info)
          for i in level:
            power += i.line()
          if power == " ":
            print("No match Dragon")
          print(power)

#Blake
        elif option == 7:
          dInfo.option_list()


        elif option == 0:
          # dInfo.write_back()
          print("All changes were saved.")
#__________________________________________________________________
  @staticmethod
  def dragon_retrievalc2():
    Analysis_Interface.print_intro()
    dInfo = DragonInfoSort()
    option = 1
    while (option != 0):
        try:
          option = int(input("Option: "))
        except ValueError:
          print("Wrong value, please try again, only input numbers 1 to 7")
          option = int(input("Option: "))
#_______________________________________________________________
        if option == 1:
          file_name = input("Enter the name of data file: ")
          dInfo.create_dragon_info(file_name)
#_______________________________________________________________
        elif option == 2:
          species = str(input("Enter the dragon species: "))
          dragon = dInfo.search_dragon(species)
          if dragon == None:
            print("Dragon not found")
          else:
            print(dragon)
#_______________________________________________________________
        elif option == 3:
          print("Enter a dragon species, power level, ability, and location!")
          name_of_species = str.lower(input("Add a dragon: "))
          add_power_level = int(input("Add the power level: "))
          add_abilities = str.lower(input("Add the abilities: "))
          add_location = str.lower(input("Add the location: "))
          dInfo.add_to_list(name_of_species, add_power_level, add_abilities, add_location)
#_______________________________________________________________
        elif option == 4:
          Announcement = str.upper(input("*WARNING YOU WILL BE DELETING A DRAGON*" + "\n" + "Are you sure Y/N: "))
#gives the user a warning that they are about to delete info, and promts the user to say yes or no before they do
          if Announcement == "Y":
            species = str.lower(input("Which species information would you like to delete? "))
            dInfo.delete_from_list(species)
#calls the delte_from_list function
          elif Announcement == "N":
            option
#_______________________________________________________________
#is the print function that will print the full list of dragons
        elif option == 5:
          print("This is the full list!")
          dInfo.print_function()        
#_______________________________________________________________
        elif option == 6:
          power_info = input("Enter the power level that you are looking for: ")
          power = " "
          level = dInfo.dragon_power_level(power_info)
          for i in level:
            power += i.line()
          if power == " ":
            print("No match Dragon")
          print(power)
#_______________________________________________________________
        elif option == 7:
          dInfo.option_list()
#calls the option function to show full list of options
#_______________________________________________________________
        elif option == 0:
          # dInfo.write_back()
          print("All changes were saved.")
#_________________________________________________________________
  @staticmethod
  def dragon_retrieval_Hash():
    Analysis_Interface.print_intro()

    dInfo = Dragon_Dictionary_Hash()
    option = 1
    while (option != 0):
        try:
          option = int(input("Option: "))
        except ValueError:
          print(
                "Wrong value, please try again, only input numbers 1 to 7")
          option = int(input("Option: "))
#_______________________________________________________________
        if option == 1:
          file_name = input("Enter the name of data file: ")
          dInfo.create_dragon_info(file_name)
#_______________________________________________________________
        elif option == 2:
          species = str.lower(input("Enter the dragon species: "))
          dragon = dInfo.search_dragon(species)
          if dragon == None:
            print("Dragon not found")
          else:
            print(dragon)
#_______________________________________________________________
        elif option == 3:
          print("Enter a dragon species, power level, ability, and location!")
          name_of_species = str.lower(input("Add a dragon: "))
          add_power_level = int(input("Add the power level: "))
          add_abilities = str.lower(input("Add the abilities: "))
          add_location = str.lower(input("Add the location: "))
          dInfo.add_to_list(name_of_species, add_power_level, add_abilities, add_location)

#_______________________________________________________________
        elif option == 4:
          Announcement = str.upper(
            input("*WARNING YOU WILL BE DELETING A DRAGON*" + "\n" +
                    "Are you sure Y/N: "))

          if Announcement == "Y":
            name_of_species = str.lower(
                input(
                      "Which species information would you like to delete? "
                  ))
            dInfo.delete_from_list(name_of_species)
#calls the delte_from_list function
          elif Announcement == "N":
            option
#_______________________________________________________________
#Blake Love
        elif option == 5:
          print("This is the full list!")
          dInfo.print_function()
#_______________________________________________________________   
#Peyton
        elif option == 6:
          power_info = input(
              "Enter the power level that you are looking for: ")
          power = " "
          level = dInfo.dragon_power_level(power_info)
          for i in level:
            power += i.line()
          if power == " ":
            print("No match Dragon")
          print(power)
#_______________________________________________________________
#Blake
        elif option == 7:
          dInfo.option_list()
#calls the option function to show full list of options
#_______________________________________________________________
# Susie
        elif option == 0:
          # dInfo.write_back()
          print("All changes were saved.")
#__________________________________________________________________
  @staticmethod
  def dragon_analysis(rand_file_name, no_queries, no_entries):

    # rand_file_name: the name of the file containing the random data
    # no_queries: the number of queries to run on the system
    # no_entries: the max number of entries in the file
    # this function is responsible for including all the necessary code to analyze the performance of the system

    # Car inventory based on list
    dinvent = Dragon_info() #Normal
    dinvent.create_dragon_info(rand_file_name)
#_________________________________________________________________
    d_dict = DragonInfoDict() #Linked List
    d_dict.create_dragon_info(rand_file_name)
#__________________________________________________________________
    d_sort = DragonInfoSort() #MergeSort
    d_sort.create_dragon_info(rand_file_name)
#__________________________________________________________________
    H_dict = Dragon_Dictionary_Hash() #Hash
    H_dict.create_dragon_info(rand_file_name)
#__________________________________________________________________
    #generating no_queries random queries 
    # using the random vin numbers
    random_dragon_list = []
    for i in range(0, no_queries):
        n = random.randint(i, no_entries)
        random_dragon_list.append(str(n))
    #Normal
    #starting time calculation
    start_time = time.time()
    results1 = []
    #running the no_queries query search
    for rand_dragon in random_dragon_list:
      result = dinvent.search_dragon(str(rand_dragon))
      results1.append(result)
    #calculating the time after the for loop
    end_time = time.time()
    # calculating how long it took to run the 1000 queries
    # print(str(results1))
    print("No of entries: "+ str(no_entries))
    print("searching " + str(no_queries) + " queries using the List based implementation: --- %s seconds ---" % (end_time - start_time))  
#_________________________________________________________________
    # starting the time calculation for the Dict based implementation
    #linkedlist
    start_time2 = time.time()
    results2 = []
    #running the no_queries query search
    for rand_dragon in random_dragon_list:
      result = d_dict.search_dragon(str(rand_dragon))
      results2.append(result)
    #calculating the time after the for loop
    end_time2 = time.time()
    # calculating how long it took to run the 1000 queries
    # print(str(results2))
    print("No of entries: "+ str(no_entries))
    print("searching " + str(no_queries) + " queries using the Dict based implementation: --- %s seconds ---" % (end_time2 - start_time2)) 
#________________________________________________________________
    #Mergesort
    start_time3 = time.time()
    results3 = []
    #running the no_queries query search
    for rand_dragon in random_dragon_list:
      result = d_sort.search_dragon(str(rand_dragon))
      results3.append(result)
    #calculating the time after the for loop
    end_time3 = time.time()
    # calculating how long it took to run the 1000 queries
    print("No of entries: "+ str(no_entries))
    print("searching " + str(no_queries) + " queries using the Sort based implementation: --- %s seconds ---" % (end_time3 - start_time3))
#_________________________________________________________________
    #Hash
    start_time4 = time.time()
    results4 = []
    #running the no_queries query search
    for rand_dragon in random_dragon_list:
      result = H_dict.search_dragon(str(rand_dragon))
      results4.append(result)
    #calculating the time after the for loop
    end_time4 = time.time()
    # calculating how long it took to run the 1000 queries
    # print(str(results4))
    print("No of entries: "+ str(no_entries))
    print("searching " + str(no_queries) + " queries using the Hash based implementation: --- %s seconds ---" % (end_time4 - start_time4))
#_________________________________________________________________ 
    # comparing to make sure the results are the same and correct
    for i in range(0, len(random_dragon_list)):
      if results1[i].get_species() != results4[i].get_species():
        print("results are not equal: ")
        print(results1[i].__species)
        print(" ")
        print(results2[i].__species)
        print("\n")
    for i in range(0, len(random_dragon_list)):
      if results4[i].get_species() != results3[i].get_species():
        print("results are not equal: ")
        print(results1[i].__species)
        print(" ")
        print(results2[i].__species)
        print("\n")