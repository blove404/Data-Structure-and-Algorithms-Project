from abstract2 import DictAbstract
class Hash_table(DictAbstract):
  def __init__(self):
    self.size = 21 #making the size
    self.column = [None] * self.size #creating the list
    self.length = 0
#_______________________________________________________________
#Calculates and gets the index of the key
#this is Hash_Function in the project
  def _Hash(self, key):
    table = 0
    for item in str(key):
      table += ord(item)
    return table % self.size
#_______________________________________________________________
#print method 
#Needs to go through find if its none
#if its none ignore the None
#or it can print None
  def _printing(self):
    print("Dragons:")
    for things in self.column:
      if things is None:
        continue
      for items in things:
        if items[0] != None:
          print(str(items[1]) + "\n")  
#_______________________________________________________________
#gets the item/finds the key
  def __getitem__(self, key):
    key_hash = self._Hash(key)
    if self.column[key_hash] is not None:
      for pair in self.column[key_hash]:
        if pair[0] == key:
          return pair[1]
    return None
#_______________________________________________________________
# #removes unwanted data
  def _remove(self, key):
    key_hash = self._Hash(key)
    if self.column[key_hash] is None:
      return "Nothing"
    for i in range (0, len(self.column[key_hash])):
      if self.column[key_hash][i][0] == key:
        self.column[key_hash].pop(i)
        return True
    return "No dragons"
#_______________________________________________________________ 
#Return the number of items stored in the dictionary
  def __contains__(self, key):
    # return True if key in self.column else False
    return not self.__getitem__(key) is None
#_______________________________________________________________
  def __len__(self):
    # return len(self.column)
    return self.length
#_______________________________________________________________
  def __setitem__(self, key, value):
    key_hash = self._Hash(key)
    key_value = [key, value]
    if self.column[key_hash] is None:
      self.column[key_hash] = list([key_value])
      return True
    else:
      for item in self.column[key_hash]:
        if item[0] == key:
          item[1] = value
          return True
      self.column[key_hash].append(key_value)
      self.length +=1
      return True