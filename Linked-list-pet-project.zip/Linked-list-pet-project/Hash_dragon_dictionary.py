from dragon import Dragons
from Hash_Table import Hash_table
from abstract2 import DragonInfoAbstract
#_______________________________________________________________
class Dragon_Dictionary_Hash(DragonInfoAbstract):
  def __init__(self):
    self.__Hash_dragon_dictionary = Hash_table()
#_______________________________________________________________ 
  def search_dragon(self, species):
    if species in self.__Hash_dragon_dictionary:
        # __list_of_dragons = dict, species = key
        return self.__Hash_dragon_dictionary.__getitem__(species)
#_______________________________________________________________
  def create_dragon_info(self, dragon_file):
    with open(dragon_file, "r") as dragon_file:
      for full_list in dragon_file:
        words = full_list.strip("\n")
        line = words.split()
        dragon = Dragons()
        dragon.set_species(line[0])
        dragon.set_powerlvl(line[1])
        dragon.set_abilities(line[2])
        dragon.set_location(line[3])
        self.__Hash_dragon_dictionary[dragon.get_species()] = dragon
# Adding the dragon objects to the list of dragons
#TODO: Change this line to add the dictionary      
#_______________________________________________________________
  def print_function(self):
#TODO:Change this implementation here to print from the dictionary
#a simple print statment that tells the user every category
    self.__Hash_dragon_dictionary._printing()

#_______________________________________________________________
#TODO: change the delete to delete from dictionary
  def delete_from_list(self, species):
    self.__Hash_dragon_dictionary._remove(species)
#_______________________________________________________________
  def add_to_list(self, name_of_species, add_power_level, add_abilities, add_location):
    search = self.search_dragon(name_of_species)
    if name_of_species == search:
      print("This dragon already exists! Give me a new dragon!")
    else:
      dragon = Dragons()
      dragon.set_species(name_of_species)
      dragon.set_powerlvl(add_power_level)
      dragon.set_abilities(add_abilities)
      dragon.set_location(add_location)
      self.__Hash_dragon_dictionary[dragon.get_species()] = dragon
#_______________________________________________________________
  def dragon_power_level(self, dragon_info):  
    new_list = []
    for i in self.__Hash_dragon_dictionary:
      if i.get_powerlvl() == dragon_info:
        new_list.append(i)
    return new_list
#_______________________________________________________________
  def write_back(self):
    with open("dragon_info_file.txt", "w") as f:
        #TODO: loop through the dictionary, get the dragon object  And write the file
      for dragon in self.__Hash_dragon_dictionary:
        f.write(str(dragon))
        f.write('\n')
#_______________________________________________________________
  def option_list(self):
    print("[0] - Exit program/Save changes!")
    print("[1]-  Input files")
    print("[3] - Add dragon info")
    print("[4] - Delete dragon info")
    print("[5] - Print dragon info list")
    print("[6] - Search by Powerlevel.")
    print("[7] - Print a reminder for all existing options!")
