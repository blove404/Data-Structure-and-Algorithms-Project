from abstract2 import DictAbstract
#_______________________________________________________________
#for some reaons the merge is acting wierd
class Merge_sort(DictAbstract):
  #initialization of dic_key, dict_value, merged_list
  def __init__(self):
    self.dict_key = []
    self.dict_value = []
    self.merged_list = []
#_______________________________________________________________
  def sort(self, key, value, l, m, r):
    # key[i] > key[j]
    # swap key[i] and key[j]
    # swap value[i] and value[j]
    #calculates the size of the subarray
    n1 = m - l + 1
    n2 = r - m
    #create temp arrays
    L = [0] * (n1)
    R = [0] * (n2)
    #copy data to tem arrays L and R
    for i in range(0, n1):
      L[i] = key[l + i]
    for j in range(0, n2):
      R[j] = key[m + 1 + j]
    A = [0] * (n1)
    B = [0] * (n2)
    #copy data to tem arrays L and R
    for i in range(0, n1):
      A[i] = value[l + i]
    for j in range(0, n2):
      B[j] = value[m + 1 + j]
    #merge the temp arrays back into arr[l,r]
    i = 0  #inital index of first subarray
    j = 0  #intitial index of second subarray
    k = l  #initial index of merged sub array
    #copy values into temporary arrays, then put them back into original locations
    while i < n1 and j < n2:
      if L[i] <= R[j]:
        key[k] = L[i]
        value[k] = A[i]
        i += 1
      else:
        key[k] = R[j]
        value[k] = B[j]
        j += 1
      k += 1
    while i < n1:
      key[k] = L[i]
      value[k] = A[i]
      i += 1
      k += 1
    while j < n2:
      key[k] = R[j]
      value[k] = B[j]
      j += 1
      k += 1
  def mergeSort(self, key, value, l, r):
    #stops when the l = the right length
    if l < r:
      # finds the middle
      m = l + (r - l) // 2
      #calls mergeSort on the left sub array
      self.mergeSort(key, value, l, m)
      #calls mergeSort on the right sub array
      self.mergeSort(key, value, m + 1, r)
      #merges two arrays together
      self.sort(key, value, l, m, r)
#_______________________________________________________________
#print method for the linked list Dictionary
  def _printing(self):
    for i in range(len(self.dict_key)):
      print(str(self.dict_key[i]) + ": " + str(self.dict_value[i]))
      print()
#_______________________________________________________________
#gets the item/finds the key
  def __getitem__(self, key):
    return self.dict_key
    # index = self._find(key)
    # if index == None:
    #   print("Nothing exists!")
#_______________________________________________________________
#sets the value to the key
  def __setitem__(self, key, value):
    if self.dict_value == None:
      print("no key and value!")
    else:
      self.dict_key.append(key)
      self.dict_value.append(value)
      self.mergeSort(self.dict_key, self.dict_value, 0, len(self.dict_key) - 1)
#_______________________________________________________________
#removes unwanted data
#Not finished have no clue
  def _remove(self, key):
    thing = self._find(key)
    item = self.dict_key.index(str(thing))
    if thing in self.dict_key:
      self.dict_value.remove(str(thing))
#_______________________________________________________________
#Searches for the key information
#is a binary search
#will search if already sorted
  def _find(self, key):
    array = self.dict_key
    low = 0
    high = len(self.dict_key) - 1
    while low <= high:
        # First calculating the mid index
        mid = low + (high - low) // 2
        # The element is present at the middle index. Return the index as the answer.
        if array[mid] == key:
          return self.dict_value[mid]
        #  If the element is smaller than the middle element, then shift the low index to mid + 1.
        elif array[mid] < key:
            low = mid + 1
        # Else shift the right index to mid - 1.
        else:
            high = mid - 1
#_______________________________________________________________  #team mate worked on
#insert method (new_dragon_info can be found in dragon_dictionary_sort)
  def insert(self, key, value):
    self.dict_key.append(key)
    self.dict_value.append(value)
#_______________________________________________________________ #teammate worked on
#Return the number of items stored in the dictionary
  def __contains__(self, key):
    # return not self._find(key)
    return True if key in self._find(key) else False
#_______________________________________________________________
#teammate worked on
  def __len__(self):
    return len(self.dict_key)
#_______________________________________________________________
# tested with str but key is empty