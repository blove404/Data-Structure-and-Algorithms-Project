class Dragons():  # created an object about dragons

    def __init__(self):  # constructor
        self.__species = ""
        self.__abilities = ""
        self.__powerlvl = 0
        self.__location = ""

#Susie worked on Species
    def get_species(self):  #gets the species
        return self.__species

    def set_species(self, species):  #sets the species
        if type(species) == int:
            print("This is not a species!")
# check if there is an entry
        else:
            self.__species = species

#Blake worked on pwrlvl, and abilities
    def get_powerlvl(self):  #will get powerlevel
        return self.__powerlvl

    def set_powerlvl(self, power):  #sets the powerlevel
        self.__powerlvl = power

    def get_abilities(self):  #gets abilities
        return self.__abilities

    def set_abilities(self, abilities):  #sets the abilities
        if type(abilities) == int:
            print("Abilities cannot be numbers.")
        else:
            self.__abilities = abilities

#peyton worked on location
    def get_location(self):  #gets the location
        return self.__location

    def set_location(self, area):  #sets the location
        if type(area) == int:
            print("This area does not exist!")
        else:
            self.__location = area
#Blake Love

    def __str__(self):
        full_list =  self.__species  + " "+ str(
            self.__powerlvl
        ) + " " +  self.__abilities + " " + self.__location 
        return full_list

