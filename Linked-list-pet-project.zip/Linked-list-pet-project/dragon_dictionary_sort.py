from dragon_2 import Dragons
from abstract2 import DragonInfoAbstract
from Sorted_List import Merge_sort
#_______________________________________________________________
class DragonInfoSort(DragonInfoAbstract):
  def __init__(self):
    self.__list_of_dragons = Merge_sort()
#_______________________________________________________________ 
  def search_dragon(self, species):
     # self.__list_of_dragons._find(species)
    index = self.__list_of_dragons._find(species)
    return (index)
#_______________________________________________________________
  def create_dragon_info(self, dragon_file):
    with open(dragon_file, "r") as dragon_file:
      for line in dragon_file:
        words = line.strip("\n")
        line = words.split()
        dragon = Dragons()
        dragon.set_species(line[0])
        dragon.set_powerlvl(line[1])
        dragon.set_abilities(line[2])
        dragon.set_location(line[3])
        self.__list_of_dragons[dragon.get_species()] = dragon
# Adding the dragon objects to the list of dragons
#TODO: Change this line to add the dictionary      
#_______________________________________________________________
  def print_function(self):
#TODO:Change this implementation here to print from the dictionary
#a simple print statment that tells the user every category
    self.__list_of_dragons._printing()

#_______________________________________________________________
#TODO: change the delete to delete from dictionary
  def delete_from_list(self, species):
    # search = self.__list_of_dragons._find(species)
    # if search == None:
    #   print("We cannot delete what isn't there!")
    # else:
    self.__list_of_dragons._remove(species)
    # delete = list(self.__list_of_dragons).index(str(search))
    # if delete == None:
    #   print("We cannot delete what isn't there!")
    # else:
    #   self.__list_of_dragons.remove(delete)
    # print(list(self.__list_of_dragons[dragon.get_species()]))
#_______________________________________________________________
  def add_to_list(self, name_of_species, add_power_level, add_abilities, add_location):
    search = self.search_dragon(name_of_species)
    if name_of_species == search:
      print("This dragon already exists! Give me a new dragon!")
    else:
      dragon = Dragons()
      dragon.set_species(name_of_species)
      dragon.set_powerlvl(add_power_level)
      dragon.set_abilities(add_abilities)
      dragon.set_location(add_location)
      self.__list_of_dragons[dragon.get_species()] = dragon
#_______________________________________________________________
  def dragon_power_level(self, dragon_info):  
    new_list = []
    for i in self.__list_of_dragons:
      if i.get_powerlvl() == dragon_info:
        new_list.append(i)
    return new_list
#_______________________________________________________________
  def write_back(self):
    # open file in write mode
    with open("dragon_info_file.txt", "w") as f:
        # loop through the dictionary, get the dragon object  And write the file
        # This loop is not going to work unless first
        # to implement an iterator to linkedlistdict class
        for i in range(len(self.__list_of_dragons)):
            # write every dragon object to the file
            f.write(str(self.__list_of_dragons.dict_key[i]))
            f.write(' ')
            f.write(str(self.__list_of_dragons.dict_value[i]))
            f.write('\n')
#_______________________________________________________________
  def option_list(self):
    print("[0] - Exit program/Save changes!")
    print("[1]-  Input files")
    print("[3] - Add dragon info")
    print("[4] - Delete dragon info")
    print("[5] - Print dragon info list")
    print("[6] - Search by Powerlevel.")
    print("[7] - Print a reminder for all existing options!")
