from dragon import Dragons
#edits done by Blake and Peyton and Susie
#Blake
class Dragon_info:
#original
  def __init__(self):
      self.__list_of_dragons = []  #creates a list of dragons
#Blake
#given the species, return a dragon object that has a matching name

  def search_dragon(self, species):
    for dragon in self.__list_of_dragons:
        if dragon.get_species() == species:
            return dragon  #returns dragon object if it is found
            return None  #if it is not found it will return null
  #Blake & Peyton
  def create_dragon_info(self, dragon_file):
    #creates the dragon information
    #loops through the file
    #for each line creates an object
    with open(dragon_file, "r") as dragon_file:
        #Reads every line
        for full_list in dragon_file:
            #Removes the new line before processing the file
            words = full_list.strip("\n")
            #Words are seperated based on spaces
            line = words.split()
            #Each line is formatted as follows:
            # Red Dragon, 18, Fire, Mountain-tops
            dragon = Dragons()
            dragon.set_species(line[0])
            if dragon.set_species(line[0]) == "":
                print("There is no dragon information!")
            dragon.set_powerlvl(line[1])
            if dragon.set_powerlvl(line[1]) == "":
                print("There is no powerlevel!")
            dragon.set_abilities(line[2])
            if dragon.set_abilities(line[2]):
                print("There is no ability set!")
            dragon.set_location(line[3])
            if dragon.set_location(line[3]):
                print("There is no location!")

# Adding the dragon objects to the list of dragons
            self.__list_of_dragons.append(dragon)

#Blake

  def print_function(self):
    #a simple print statement that tells the user every category
    for element in range(len(self.__list_of_dragons)):
      print(str(self.__list_of_dragons[element]), "\n")
#prints the dragon list and makes a new line each time
    if bool(self.__list_of_dragons):
      #checks if its the end of the list and
      #lets the user know
      print(
          "It seems like there are no more dragons in the list." + "\n" +
          "Perhaps you would like to add or delete a dragon." + "\n" +
          "Well you most certainly can!" + "\n" +
          "Remember if you want to add a dragon hit option 3, if you want to delete a dragon hit option 4!"
          + "\n" + "Hope this helped, have a great day")
#the above portion will look at the entire list,
#then print the list
#at the same time will make a new line to separate each
#dragon species.
#then at the end of list it will inform the user they
#are at the end of the list and they can take steps to
#add or delete dragon species
#Blake
  def delete_from_list(self, name_of_species):
    search = self.search_dragon(name_of_species)
    # Call the search function
    # take the return
    # use list.remove to remove that object
    if search == None:
      print("We cannot delete what isn't there!")
    else:
      self.__list_of_dragons.remove(search)
    #removes from list

  def add_to_list(self, name_of_species):
    name = name_of_species
    search = self.search_dragon(name)
    if name == search:
      print("This dragon already exists! Give me a new dragon!")
    else:
      self.__list_of_dragons.append(name)
  
  def dragon_power_level(self, dragon_info):#Peyton
    new_list = []
    for i in self.__list_of_dragons:
      if i.get_powerlvl() == dragon_info:
        new_list.append(i)
    return new_list

  # filters the list of dragons based on powerlevel
  #pass

  # Susie
  # write back to the file

  def write_back(self):
    with open("dragon_info_file.txt", "w") as f:
        #TODO: loop through the dictionary, get the dragon object  And write the file
      for dragon in self.__list_of_dragons:
        f.write(str(dragon))
        f.write('\n')
#Blake
  def option_list(self):
      print("[0] - Exit program/Save changes!")
      print("[1]-  Input files")
      print("[3] - Add dragon info")
      print("[4] - Delete dragon info")
      print("[5] - Print dragon info list")
      print("[6] - Search by Powerlevel.")
      print("[7] - Print a reminder for all existing options!")
