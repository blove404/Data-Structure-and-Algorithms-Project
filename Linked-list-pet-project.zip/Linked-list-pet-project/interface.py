from dragon_dict import *
from dragon import Dragons
#from dragon_info import Dragon_info
class Interface:
  @staticmethod
  def print_intro():
      print("                   * * * * * * *")
      print("                *                *")
      print("               *  * * * * * * * *     *")
      print("         * *  *  * * * *        * * * *")
      print("       *                *")
      print("     *  0                  *")
      print("  *                         *")
      print("*Welcome to our Dragon Retrieval System")
      print("*         *                     *")
      print(" * * * * *                           *")
      print("    *                *  * *")
      print("      *            *         *")
      print("        *  *  *  *            *")
      print("                                 *")
      print("Before putting in options, you must enter a file [1]")
      print("[0] - Exit program/Save changes!")
      print("[1] - Input file")
      print("[2] - Input query")
      print("[3] - Add dragon info")
      print("[4] - Delete dragon info")
      print("[5] - Print dragon info list")
      print("[6] - Search by Powerlevel.")
      print("[7] - Print a reminder for all existing options!")

  @staticmethod
  def dragon_retrieval_dictionary():
    Interface.print_intro()

    dInfo = DragonInfoDict()
    option = 1
    while (option != 0):
        try:
          option = int(input("Option: "))
        except ValueError:
          print(
                "Wrong value, please try again, only input numbers 1 to 7")
          option = int(input("Option: "))

        if option == 1:
          file_name = input("Enter the name of data file: ")
          dInfo.create_dragon_info(file_name)

        elif option == 2:
          species = str.lower(input("Enter the dragon species: "))
          dragon = dInfo.search_dragon(species)
          if dragon == None:
            print("Dragon not found")
          else:
            print(dragon)


        elif option == 3:
          print("Enter a dragon species, power level, ability, and location!")
          name_of_species = str.lower(input("Add a dragon: "))
          add_power_level = int(input("Add the power level: "))
          add_abilities = str.lower(input("Add the abilities: "))
          add_location = str.lower(input("Add the location: "))
          dInfo.add_to_list(name_of_species, add_power_level, add_abilities, add_location)


        elif option == 4:
          Announcement = str.upper(
            input("*WARNING YOU WILL BE DELETING A DRAGON*" + "\n" +
                    "Are you sure Y/N: "))

          if Announcement == "Y":
            name_of_species = str.lower(
                input(
                      "Which species information would you like to delete? "
                  ))
            dInfo.delete_from_dictionary(name_of_species)
#calls the delte_from_list function
          elif Announcement == "N":
            option
#Blake Love
        elif option == 5:
          print("This is the full list!")
          dInfo.print_dictionary()
        
#Peyton
        elif option == 6:
          power_info = input(
              "Enter the power level that you are looking for: ")
          power = " "
          level = dInfo.dragon_power_level(power_info)
          for i in level:
            power += i.line()
          if power == " ":
            print("No match Dragon")
          print(power)

#Blake
        elif option == 7:
          dInfo.option_list()


#calls the option function to show full list of options

# Susie
        elif option == 0:
          dInfo.write_back()
          print("All changes were saved.")
