from abstract import DictAbstract

class Node:
  def __init__(self, key, data):
      self._key = key
      self._data = data
      self.next = None
  def __str__(self):
      return str(self._key) + ":" + str(self._data)
      #returns key and value as a string

class DictLinkedList(DictAbstract):
  def __init__(self):
      #first node in the list
      #start with an empty list
      self.head = None
      self.size = 0

#insert method for linked list
  def insert(self, key, data):
      #add a node whose data is the temp argument to the front
      #of the linked list
      temp = Node(key, data)
      temp.next = self.head
      self.head = temp

      #print method for the linked list Dictionary
  def _printing(self):
    if self.head == None:
        print("Data is not here!")
    else:
        current = self.head
        while current:
            #prints the data
            # Added by Dr. Hatem
            print(str(current._key) + ":" + str(current._data))
            current = current.next

#Searches the Nodes
  def _find(self, key):
    current = self.head
    if self.head is None:
        print("Linked list is empty. No Nodes to search!")
    while current is not None:
        if current._key == key:
            # Changed by Dr. Hatem
          return current._data
          #return True
        else:
            current = current.next
            # Changed by Dr. Hatem
            #return False
    return None

  #gets the item/finds the key
  def __getitem__(self, key):
      item = self._find(key)
      if item == None:
          raise KeyError("Item does not exist")
      return item

  #sets the item
  def __setitem__(self, key, data):
      if self.head == None:
          self.head = Node(key, data)
          self.size += 1
      else:
          self.insert(key, data)

      
      #removes item at specific index   
  def pop(self, key):
      value = self[key]
      self.remove(key)
      self.size = self.size - 1
      return value

 
#removes unwanted data
  def remove(self, key):
      previous = 0
      current = self.head
      if current == None:
          print("The Linked List is empty, nothing to remove!")
      if current is not None:
          if current._key == key:
              self._head = current.next
              current = None
              return
# checks to see if others are None
      while current is not None:
          if current._key == key:
              break
          previous = current
          current = current.next
      if current == None:  #when list has nothing inside it
          print("Nothing is found inside the Node!")
          return
          #delete
      previous.next = current.next
      current = None

     
  def edit(self, key, data):
      #iterate from the head of list
      current_node = self.head
      # no editing if empty list
      if current_node == None:
          print("The linked list is empty, no edition can be made")
      while current_node != None:
          if current_node._key == key:
              current_node._data = data
              # once key is found, loop stops
              break
          else:
              current_node = current_node.next


  def __len__(self):
      #iterate from the head of list
      current_node = self.head
      self.size = 0
      #loops as long as not reaching the end of list [next = None]
      while current_node != None:
          self.size += 1
          current_node = current_node.next
      # return number of nodes in dictionary
      return self.size

  
  def __contains__(self, key):
      #return true if keys found, otherwise false
      return not self._find(key) is None

  
