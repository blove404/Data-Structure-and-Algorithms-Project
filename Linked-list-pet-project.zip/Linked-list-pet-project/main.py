#Blake
from main_dragon_inventory import *  # imports from main_dragon_inventory
from interface import Interface  #Linked list
from Interface2 import Interface2 #sorted list
from original_interface import Original_Interface #step 5
from Hash_interface import Hash_Interface #hash function
from random_file import generate_data
from Analysis_interface import Analysis_Interface
from test import test


#__________________________________________________________________
def main_analysis():
  no_entries = 100
  file_name = "rand_file_" + str(no_entries) + ".txt"
  generate_data(file_name, no_entries)
  Analysis_Interface.dragon_analysis(file_name, 100, no_entries)


#__________________________________________________________________
def main_analysis2():
  no_entries = 1000
  file_name = "rand_file_" + str(no_entries) + ".txt"
  generate_data(file_name, no_entries)
  Analysis_Interface.dragon_analysis(file_name, 1000, no_entries)


#__________________________________________________________________
def main_analysis3():
  no_entries = 10000
  file_name = "rand_file_" + str(no_entries) + ".txt"
  generate_data(file_name, no_entries)
  Analysis_Interface.dragon_analysis(file_name, 10000, no_entries)


#___________________________________________________________________
def main_analysis4():
  no_entries = 100000
  file_name = "rand_file_" + str(no_entries) + ".txt"
  generate_data(file_name, no_entries)
  Analysis_Interface.dragon_analysis(file_name, 100000, no_entries)


#__________________________________________________________________
if __name__ == "__main__":
  #main_retrieval()  #calls to the main
  #Original_Interface.dragon_retrievalcl()  #step 5
   Interface.dragon_retrieval_dictionary() #Linkedlist
  # Interface2.dragon_retrievalc2() #Sorted list
  # Hash_Interface.dragon_retrieval_Hash() #Hash
  # main_analysis()
  # print("___________________________________________")
  # main_analysis2()
  # print("__________________________________________")
  # main_analysis3()
  # print("_________________________________________")
  # main_analysis4()
  # test = test()
  # test.insert("k", "j")
  # test.insert("j", "k")
  # test.insert("n", "m")
  # test.insert("m", "n")
  # test._printing()
  # variable = test._find("m")
  # print(variable)
