# Susie, Blake and Peyton
#imports
from dragon import Dragons
from dragon_info import Dragon_info


def main():  #main

    D = Dragons()  #creates a variable that stores the dragon object

    D.set_species("Red Dragon")  #name of dragon species
    D.set_powerlvl(18)  #power level of the dragon
    D.set_abilities("Fire breathing")  #abilities of the dragon

    D.set_location("Mountain Tops")  #where the dragon lives

    print("Dragon info: " + D.get_species() + ", " + str(D.get_powerlvl()) +
          ", " + D.get_abilities() + ", " + D.get_location())


# Susie
# implement a simple main to ensure no errors
def main_retrieval():
    d_info = Dragon_info()
    d_info.create_dragon_info("dragon_info_file.txt")
    species = str.lower(
        input("Enter a dragon species: "
              ))  # reading dragon specie input and convert into string

    # search for the given dragon specie
    dragon = d_info.search_dragon(species)
    # if no matching speice from the dragon list
    if dragon == None:
        print(
            "Dragon not found, you may have a spelling error, or the dragon does not yet exist!!"
        )
    else:
        print("Dragon info: " + dragon.get_species() + ", " +
              str(dragon.get_powerlvl()) + ", " + dragon.get_abilities() +
              ", " + dragon.get_location())
