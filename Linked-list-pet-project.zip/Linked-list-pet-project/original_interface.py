from dragon_info import Dragon_info
from dragon import Dragons


# hold the functions for the interface
class Original_Interface:
    # when method is called, we don't pass an instance of the class to it
    @staticmethod
    def print_intro():
        print("                   * * * * * * *")
        print("                *                *")
        print("               *  * * * * * * * *     *")
        print("         * *  *  * * * *        * * * *")
        print("       *                *")
        print("     *  0                  *")
        print("  *                         *")
        print("*Welcome to our Dragon Retrieval System")
        print("*         *                     *")
        print(" * * * * *                           *")
        print("    *                *  * *")
        print("      *            *         *")
        print("        *  *  *  *            *")
        print("                                 *")
        #Susie
        print("Before putting in options, you must enter a file [1]")
        print("[0] - Exit program/Save changes!")
        print("[1] - Input file")
        print("[2] - Input query")
        print("[3] - Add dragon info")
        print("[4] - Delete dragon info")
        print("[5] - Print dragon info list")
        print("[6] - Search by Powerlevel.")
        print("[7] - Print a reminder for all existing options!")

    @staticmethod
    # a command line interface for dragon info retrieval system
    def dragon_retrievalcl():
        Original_Interface.print_intro()

        dInfo = Dragon_info()
        #Susie
        option = 1
        while (option != 0):
            #exception handling
            try:
                option = int(input("Option: "))
            except ValueError:
                print(
                    "Wrong value, please try again, only input numbers 1 to 7")
                option = int(input("Option: "))
            #Susie
            # enter the path to the files to build the system
            if option == 1:
                file_name = input("Enter the name of data file: ")
                dInfo.create_dragon_info(file_name)
            #Susie
            elif option == 2:
                species = str.lower(input("Enter the dragon species: "))
                dragon = dInfo.search_dragon(species)
                if dragon == None:
                    print("Dragon not found")
                else:
                    print(dragon)

            #Peyton
            elif option == 3:
                print(
                    "Enter a dragon species, power level, ability, and location!"
                )
                name_of_species = str.lower(input("Add a dragon: "))
                dInfo.add_to_list(name_of_species)

#Blake Love
            elif option == 4:
                Announcement = str.upper(
                    input("*WARNING YOU WILL BE DELETING A DRAGON*" + "\n" +
                          "Are you sure Y/N: "))
                #gives the user a warning that they are about to delete info, and promts the user to say yes or no before they do
                if Announcement == "Y":
                    name_of_species = str.lower(
                        input(
                            "Which species information would you like to delete? "
                        ))
                    dInfo.delete_from_list(name_of_species)
#calls the delte_from_list function
                elif Announcement == "N":
                    option
#Blake Love
            elif option == 5:
                print("This is the full list!")
                dInfo.print_function()
            #Susie - backup function, call __str__ for printing
            #   print(dInfo)
#shows the whole list
#Peyton
            elif option == 6:
                power_info = input(
                    "Enter the power level that you are looking for: ")
                power = " "
                level = dInfo.dragon_power_level(power_info)
                for i in level:
                  power += i.line()
                if power == " ":
                  print("No match Dragon")
                print(power)

#Blake
            elif option == 7:
                dInfo.option_list()

#calls the option function to show full list of options
# Susie
            elif option == 0:
                dInfo.write_back()
                print("All changes were saved.")

