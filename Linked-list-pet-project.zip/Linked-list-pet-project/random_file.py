import random
import os

# Generating random data. The car information is not important, rather the car vin number needs to be unique
def generate_data(rand_file_name, no_entries):
  # rand_file_name: the name of the random 
  # no_entries: the number of entries in the file
  file_name = "temp.txt" # temp file to hold the generated entries
  with open(file_name, 'w') as writefile:
    for i in range(1, no_entries + 1):
      dragon_species =  str(i)
      dragon_powerlvl =  12
      dragon_location = "volcanoes"
      dragon_abilities = "lava"
      writefile.write(dragon_species + " " + str(dragon_powerlvl) + " " + dragon_abilities + " " + dragon_location + "\n")


  # randmize the entries in the file
  with open(file_name,'r') as source:
    data = [ (random.random(), line) for line in source ]
  data.sort()
  with open(rand_file_name,'w') as target:
    for _, line in data:
        target.write( line )

  # removing the temp file, not needed anymore
  os.remove(file_name)